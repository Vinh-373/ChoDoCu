import axios from "axios";

export const TOKEN_KEY = "chodocu.token";
export const USER_KEY = "chodocu.user";
export const AUTH_EXPIRED_EVENT = "chodocu:auth-expired";

// Dev: để trống → dùng "/api" và Vite proxy chuyển sang BE. Deploy: đặt VITE_API_URL.
const client = axios.create({
  baseURL: import.meta.env.VITE_API_URL || "/api",
});

client.interceptors.request.use((config) => {
  const token = localStorage.getItem(TOKEN_KEY);
  if (token) config.headers.Authorization = `Bearer ${token}`;
  return config;
});

client.interceptors.response.use(
  (res) => res,
  (error) => {
    const status = error.response?.status;
    const url: string = error.config?.url ?? "";
    // 401 ở trang đăng nhập/đăng ký là sai mật khẩu, không phải hết phiên.
    if (status === 401 && localStorage.getItem(TOKEN_KEY) && !url.includes("/auth/")) {
      window.dispatchEvent(new Event(AUTH_EXPIRED_EVENT));
    }
    return Promise.reject(error);
  },
);

export default client;
